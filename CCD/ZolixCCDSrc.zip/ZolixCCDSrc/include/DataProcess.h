#pragma once
#include "stdafx.h"
#include <iostream>
using namespace std;
//�������������ݽ���ˮƽ��ת
template<class T1,class T2>
void CIsMirror(T1 sMirror,T1 nPixSize,T2 *pSur,T2 *pDst)
{
	if (sMirror==1)
	{
		reverse(pSur,(pSur+nPixSize));
	}
		memcpy(pDst,pSur,sizeof(double)*nPixSize);

}
template<class T1,class T2,class T3>
void Float2Long(T1 *Src,T2 *Dst,T3 nPixSize)
{
	for (int i=0;i<nPixSize;i++)
	{
		Dst[i]=(T1)Src[i];
	}
} 
template<class T1,class T2,class T3>
T1 * CamPixProcessing(T1 *intensityData,T2 MaxSize,T2 iCCDNUM,T3 strCCD)
{
	CString strvalue;
	int num=0;
	T1 first=0;
	int m_Num=0;
	BOOL nSt=TRUE;
	CStringArray sGataWave;
	if (iCCDNUM>0)
	{
		sGataWave.RemoveAll();
		Split(strCCD,";",sGataWave);
		for (int i=0;i<sGataWave.GetSize();i++)
		{
			if (i>=(sGataWave.GetSize()-1))
			{
				nSt=FALSE;
			}
			while (nSt&&(atoi(sGataWave.GetAt(i))+1)==atoi(sGataWave.GetAt(i+1)))
			{
				num++;
				i++;
				if (i==(sGataWave.GetSize()-1))
				{
					nSt=FALSE;
				}
			}

			if (num==0)
			{
				if (atoi(sGataWave.GetAt(i))<MaxSize-1)
				{
					if(atoi(sGataWave.GetAt(i))==0)
					{
						first=intensityData[1];
					}
					else
					{
						first=intensityData[atoi(sGataWave.GetAt(i))-1];
					}
					intensityData[atoi(sGataWave.GetAt(i))]=(first+intensityData[atoi(sGataWave.GetAt(i))+1])/2;
				}
				else
				{
					intensityData[atoi(sGataWave.GetAt(i))]=(intensityData[atoi(sGataWave.GetAt(i))-2]+intensityData[atoi(sGataWave.GetAt(i))-1])/2;
				}
			}
			else
			{
				m_Num=num;
				while(m_Num!=-1)
				{
					if (atoi(sGataWave.GetAt(i))<MaxSize-1)
					{
						if((atoi(sGataWave.GetAt(i))-num)==0)
						{
							first=0.0;
						}
						else
						{
							first=intensityData[atoi(sGataWave.GetAt(i))-num-1];
						}
						intensityData[atoi(sGataWave.GetAt(i))-m_Num]=first+(num+1-m_Num)*(intensityData[atoi(sGataWave.GetAt(i))+1]-first)/(num+2);
					}
					else
					{
						intensityData[atoi(sGataWave.GetAt(i))-m_Num]=(intensityData[atoi(sGataWave.GetAt(i))-m_Num-2]+intensityData[atoi(sGataWave.GetAt(i))-m_Num-1])/2;

					}
					m_Num--;
				}
			}
			num=0;
		}
	}	
	return intensityData;
}