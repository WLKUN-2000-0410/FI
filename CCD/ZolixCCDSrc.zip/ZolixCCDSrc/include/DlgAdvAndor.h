#pragma once


// CDlgAdvAndor �Ի���
#include "MFCResMacros.h"
#include "..\common\resource.h"

NS_MFC_Res_BEGIN
class CDlgAdvAndor : public CDialog
{
	DECLARE_DYNAMIC(CDlgAdvAndor)

public:
	CDlgAdvAndor(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgAdvAndor();

// �Ի�������
	enum { IDD = ID_DLG_ADV };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonCcd();
	afx_msg void OnCbnSelchangeComboMirror();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
NS_MFC_Res_END