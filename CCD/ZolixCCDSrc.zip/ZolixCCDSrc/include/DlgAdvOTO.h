#pragma once


#include "MFCResMacros.h"
#include "..\common\resource.h"

NS_MFC_Res_BEGIN
class CDlgAdvOTO : public CDialog
{
	DECLARE_DYNAMIC(CDlgAdvOTO)

public:
	CDlgAdvOTO(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgAdvOTO();

	// �Ի�������
	enum { IDD = ID_DLG_ADV };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonCcd();
	afx_msg void OnCbnSelchangeComboMirror();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
NS_MFC_Res_END