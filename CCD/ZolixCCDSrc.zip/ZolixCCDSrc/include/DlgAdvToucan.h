#pragma once


// CDlgAdvMity �Ի���
#include "MFCResMacros.h"
#include "..\common\resource.h"

NS_MFC_Res_BEGIN
class CDlgAdvToucan : public CDialog
{
	DECLARE_DYNAMIC(CDlgAdvToucan)

public:
	CDlgAdvToucan(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgAdvToucan();

// �Ի�������
	enum { IDD = ID_DLG_ADV };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonCcd();
	afx_msg void OnCbnSelchangeComboMirror();
	afx_msg void OnClose();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
NS_MFC_Res_END