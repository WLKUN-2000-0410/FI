#pragma once


// CDlgPassword �Ի���
#include "MFCResMacros.h"
#include "..\common\resource.h"

NS_MFC_Res_BEGIN
class CDlgPassword : public CDialog
{
	DECLARE_DYNAMIC(CDlgPassword)

public:
	CDlgPassword(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPassword();

// �Ի�������
	enum { IDD = ID_DLG_PASSWORD };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonCcd();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
NS_MFC_Res_END